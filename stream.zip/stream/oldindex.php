
<?php 


$directory = getcwd()."/doc/"; 
$longlistDir = getcwd()."/doc_array/";

/*  
// Initialize filecount variavle 
$filecount = 0; 
$files2 = glob( $directory ."*" ); 
if( $files2 ) { 
    $filecount = count($files2); 
} 
echo "Total ".$filecount."files <br>"; 
*/

// $array = array('apple', 'orange', 'strawberry', 'blueberry', 'kiwi', 'strawberry');
// $array_without_strawberries = array_diff($array, array('strawberry', 'blueberry'));
// print_r($array_without_strawberries);

// print_r($files1);
// ****** Step 1 *****
echo "<h1>Step 1:</h1>";
$files2 = scandir($directory, 1);
foreach($files2 as $key=>$file){
	if($file != "." && $file != "..") {
		echo "<h4 style='margin-bottom: 5px;'>".$file."</h4>";
		$myfile = fopen($directory.$file, "r")or die("Unable to open file!");
		echo file_get_contents($directory.$file);
		// readfile($myfile);
		// $file = fopen("data.txt", "r"); 
		$count = "";
		//Gets each line till end of file is reached  
		/* while (($line = fgets($myfile)) !== false) {  
			//Splits each line into words  
			if($file == "doc1.txt"){

				$doc1_array = explode(" ", $line);
				echo "<pre>";
				print_r($doc1_array);
				echo "</pre>"; 
			}else if($file == "longlist_array.txt"){

				$longlist_array = explode(" ", $line);
				//echo "longlist array";
				echo "<pre>";
				//print_r($longlist_array);
				echo "</pre>"; 
				echo '<br/>';
				echo '<br/>';
			}else {
				$words = explode(" ", $line); 
				//Counts each word  
				echo "<pre>";
				print_r($words);
				echo "</pre>"; 
				echo '<br/>';
				echo '<br/>';
			}
		} */  
		//print("Number of words present in given file: ".$count."<br><br>");  
		fclose($myfile);
	}
}

// ****** Step 2 *****
echo "<h1>Step 2:</h1>";

$longlist_files = scandir($longlistDir, 1);
foreach($longlist_files as $key=>$longlist_file){
	if($longlist_file != "." && $longlist_file != "..") {
		$myfile = fopen($longlistDir.$longlist_file, "r")or die("Unable to open file!");
		while (($line = fgets($myfile)) !== false) {  
			$longlist_array[$key] = explode(" ", $line);
			//echo "longlist array";
			echo "<pre>";
			print_r($longlist_array);
			echo "</pre>"; 
			echo '<br/>';
		}
	}
}
foreach($files2 as $key=>$file){
	if($file != "." && $file != "..") {
		echo "<h4 style='margin-bottom: 5px;'>".$file."</h4>";
		$myfile = fopen($directory.$file, "r")or die("Unable to open file!");
		echo file_get_contents($directory.$file);
		// readfile($myfile);
		// $file = fopen("data.txt", "r"); 
		$count = "";
		//Gets each line till end of file is reached  
		/* while (($line = fgets($myfile)) !== false) {  
			//Splits each line into words  
			if($file == "doc1.txt"){

				$doc1_array = explode(" ", $line);
				echo "<pre>";
				print_r($doc1_array);
				echo "</pre>"; 
			}else if($file == "longlist_array.txt"){

				$longlist_array = explode(" ", $line);
				//echo "longlist array";
				echo "<pre>";
				//print_r($longlist_array);
				echo "</pre>"; 
				echo '<br/>';
				echo '<br/>';
			}else {
				$words = explode(" ", $line); 
				//Counts each word  
				echo "<pre>";
				print_r($words);
				echo "</pre>"; 
				echo '<br/>';
				echo '<br/>';
			}
		} */  
		//print("Number of words present in given file: ".$count."<br><br>");  
		fclose($myfile);
	}
}
// foreach($longlist_array as $key => $data_array) {
  
  
        
        // foreach($doc1_array as  $key => $doc1) {
        	
           // if(in_array($doc1_array, $data_array)){
    				// //echo $doc1. "<br/>";
    				
			// }
			
        // }
// }	  

// $longlist_length = count($longlist_array);
//  $doc1_length = count($doc1_array);

//  for ($i = 0; $i < $longlist_array; $i++) {	
// 		for ($j = 0; $j < $doc1_length; $j++) {
// 			//if($doc1_array[$j] == $longlist_array[$i])
// 			//{
// 				//echo $doc1_array[$j] . "<br>";
// 			//}  
			
// 		}
		
// 	}



?>