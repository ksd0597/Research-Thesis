<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<title>Stream</title>
		<!-- Bootstrap core CSS -->
		<link href="/stream/assets/bootstrap/bootstrap.min.css" rel="stylesheet">
	</head>
<body>
<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'lib/stemmerClass.php';
require_once 'lib/PorterStemmer.php';
$directory = getcwd()."/doc/"; 
$longlistDir = getcwd()."/doc_array/";

// ****** Step 1 Start*****
?>
<div class="container">
<h1 class='text-center'>Step 1:</h1>
<table class="table table-bordered">
	<thead>
		<tr>
			<th>Document Name</th>
			<th>Content</th>
		</tr>
	</thead>
	<tbody>
	<?php
		$files2 = scandir($directory, 1);
		foreach($files2 as $key=>$file){
			if($file != "." && $file != "..") {
				$myfile = fopen($directory.$file, "r")or die("Unable to open file!");
				// echo file_get_contents($directory.$file);
	?>
				<tr>
					<td><?php echo $file; ?></td>
					<td><?php echo file_get_contents($directory.$file); ?></td>
				</tr>
	<?php
				fclose($myfile);
			}
		}
	?>
	</tbody>
</table>
</div>
<?php
// ****** Step 1 End*****

// ****** Step 2 Start*****
$longlist_files = scandir($longlistDir, 1);
foreach($longlist_files as $key=>$longlist_file){
	if($longlist_file != "." && $longlist_file != "..") {
		$myfile = fopen($longlistDir.$longlist_file, "r")or die("Unable to open file!");
		while (($line = fgets($myfile)) !== false) {  
			$longlist_array[$key] = array_map('strtolower', explode(" ", $line));
		}
	}
}
foreach($files2 as $key=>$file){
	if($file != "." && $file != "..") {
		$myfile = fopen($directory.$file, "r")or die("Unable to open file!");
		$stream_file = "";
		while (($line = fgets($myfile)) !== false) {  
			$stream_file = array_map('strtolower', explode(" ", $line));
			
			foreach($longlist_array as $longlist){
				$stream_file = array_diff($stream_file, $longlist);
			}
		}
		$stemmer_obj = new Stemmer();
		$stem_res[$key]['file'] = $file;
		$stem_res[$key]['content'] = $stemmer_obj->stem_list($stream_file);
		fclose($myfile);
	}
}
?>
<div class="container">
	<h1 class='text-center'>Step 2:</h1>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Document Name</th>
				<th>Content</th>
			</tr>
		</thead>
		<tbody>
		<?php
			foreach($stem_res as $stem_arr){
		?>
				<tr>
					<td><?php echo $stem_arr['file']; ?></td>
					<td>
						<?php 
							$steam_content = $stem_arr['content'];
							foreach($steam_content as $stem_val){
								echo $stem_val." ";
							}
						?>
					</td>
				</tr>
		<?php
			}
			?>
	</tbody>
</table>
</div>
<?
// ****** Step 2 End*****

// ****** Step 3 Start*****
?>
<div class="container">
	<h1 class='text-center'>Step 3:</h1>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Document Name</th>
				<th>Content</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$total_array = array();
			$i = 0;
			foreach($stem_res as $stem_arr){
		?>
			<tr>
				<td><?php echo $stem_arr['file']; ?></td>
				<td>
					<?php
						$steam_content = $stem_arr['content'];
						$group_words = array_count_values($steam_content);
						foreach (array_keys($total_array + $group_words) as $key) {
							$total_array[$key] = (isset($total_array[$key]) ? $total_array[$key] : 0) + (isset($group_words[$key]) ? $group_words[$key] : 0);
						}
						foreach($group_words as $key=>$group_word){
							echo $key." - ".$group_word."<br>";
						}
					?>
				</td>
			</tr>
		<?php } ?>
		</tbody>
	</table>
</div>
<?php
// ****** Step 3 End*****

// ****** Step 4 Start*****
$max_count = 3;
$match_arr = array();
array_multisort($total_array, SORT_DESC);
$i=0;
$last_val=0;
$result = array();
foreach($total_array as $key=>$array_val){
	if($last_val == 0){
		$last_val = $array_val;
	}
	if(($last_val >= $array_val) && ($i < $max_count)){
		if($last_val == $array_val){
			$match_arr['group_'.$i][$key] = $array_val;
			$result['group_'.$i] = array();
		}else {
			$i = $i+1;
			if($i < $max_count){
				$match_arr['group_'.$i][$key] = $array_val;
				$result['group_'.$i] = array();
			}
		}
	}
	$last_val = $array_val;
}
// print_r($match_arr);
?>
<div class="container">
	<h1 class='text-center'>Step 4:</h1>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Group</th>
				<th>Content</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$i = 1;
			foreach($match_arr as $match_row){
				echo "<tr>";
				echo "<td>Group ".$i."</td>";
				echo "<td>";
				foreach($match_row as $match_word=>$match_key){
					echo $match_word." - ".$match_key."<br>";
				}
				echo "</td>";
				echo "</tr>";
				$i++;
			}
		?>
		</tbody>
	</table>
</div>		
<?php
// ****** Step 4 End*****

// ****** Step 5 Start*****
$i=0;
$result['no_match'] = array();
foreach($stem_res as $stem_arr){
	$steam_content = $stem_arr['content'];
	$group_words = array_count_values($steam_content);
	array_multisort($group_words, SORT_DESC);
	$no_match = 0;
	foreach($group_words as $group_key=>$group_word){
		foreach($match_arr as $match_key=>$match_inner) {
			if(array_key_exists($group_key, $match_inner)){
				array_push($result[$match_key], $stem_arr['file']);
				$no_match = 1;
				break 2;
			}
		}
	}
	if($no_match == 0){
		array_push($result['no_match'], $stem_arr['file']);
	}
	$i++;
}
// print_r($result);
?>
<div class="container">
	<h1 class='text-center'>Step 5:</h1>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Group</th>
				<th>Document Name</th>
			</tr>
		</thead>
		<tbody>
		<?php 
			foreach($result as $result_key=>$result_arr){
				echo "<tr>";
				if($result_key == 'no_match'){
					echo "<td>No Match</td>";
				}else {
					echo "<td>";
					foreach($match_arr[$result_key] as $match_key=>$match_row){
						echo $match_key."<br>";
					}
					echo "</td>";
				}
				// echo "<td>".$result_key."</td>";
				echo "<td>";
				foreach($result_arr as $document_name){
					echo $document_name."<br>";
				}
				echo "</td>";
				echo "</tr>";
		} 
		?>
			
		</tbody>
	</table>
</div>
<?php
// ****** Step 5 End*****
?>
<script src="/stream/assets/jquery-3.5.1.min.js"></script>
<script src="/stream/assets/bootstrap/bootstrap.bundle.min.js"></script>
</body>
</html>