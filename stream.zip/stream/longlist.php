
<?php 
  
// Set the current working directory 
$directory = getcwd()."/doc_array/"; 
  
// Initialize filecount variavle 
$filecount = 0; 
  
$files2 = glob( $directory ."*" ); 
  
if( $files2 ) { 
    $filecount = count($files2); 
} 
  
//echo $filecount . "files <br>"; 

$dir    = '/doc_array';
// $files1 = scan($directory, "jpg");
$files2 = scandir($directory, 1);

// print_r($files1);
// print_r($files2);
foreach($files2 as $key=>$file){
	if($file != "." && $file != "..") {
		//echo "<br>".$file;
		$myfile = fopen($directory.$file, "r")or die("Unable to open file!");
		// readfile($myfile);
		// $file = fopen("data.txt", "r");  
		$count = "";
		//Gets each line till end of file is reached  
		while (($line = fgets($myfile)) !== false) {  
			//Splits each line into words  
			$array_long_list = explode(" ", $line);  
			//Counts each word  
			echo "<pre>";
			print_r($array_long_list); //array stored;
			echo "</pre>";
			$count = $count + count($words);  
		}  
		   
		print("Number of words present in given file: ".$count."<br><br>");  
		fclose($myfile);
	}
}
  
?> 